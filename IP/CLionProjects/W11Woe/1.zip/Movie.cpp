#include "Movie.h"
#include <sstream>
using namespace std;

// Constructor
Movie::Movie(int year, const string& director, const string& title, const string& genre,
             const vector<string>& actors, double rating)
    : year(year), director(director), title(title), genre(genre), actors(actors), rating(rating) {}

// Getters
int Movie::getYear() const {
    return year;
}
string Movie::getDirector() const {
    return director;
}
string Movie::getTitle() const {
    return title;
}
string Movie::getGenre() const {
    return genre;
}
vector<string> Movie::getActors() const {
    return actors;
}
double Movie::getRating() const {
    return rating;
}
// Setters
void Movie::setYear(int year) {
    this->year = year;
}
void Movie::setDirector(const string& director) {
    this->director = director;
}
void Movie::setTitle(const string& title) {
    this->title = title;
}
void Movie::setGenre(const string& genre) {
    this->genre = genre;
}
void Movie::setActors(const vector<string>& actors) {
    this->actors = actors;
}
void Movie::setRating(double rating) {
    this->rating = rating;
}
string Movie::toString() const {
    ostringstream output;
    output << title << " (" << year << ")";
    return output.str();
}

void Movie::starring(const string& actor) {
    actors.push_back(actor);
}

