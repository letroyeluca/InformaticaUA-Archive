#ifndef MOVIE_H
#define MOVIE_H

#include <string>
#include <vector>
using namespace std;

class Movie {
private:
    int year;
    string director;
    string title;
    string genre;
    vector<string> actors;
    double rating;

public:
    // Constructor
    Movie(int year, const string& director, const string& title, const string& genre,
          const vector<string>& actors, double rating);

    // Getters
    int getYear() const;
    string getDirector() const;
    string getTitle() const;
    string getGenre() const;
    vector<string> getActors() const;
    double getRating() const;
    // Setters
    void setYear(int year);
    void setDirector(const string& director);
    void setTitle(const string& title);
    void setGenre(const string& genre);
    void setActors(const vector<string>& actors);
    void setRating(double rating);

    // Additional Methods
    string toString() const;
    void starring(const string& actor);
};

#endif
