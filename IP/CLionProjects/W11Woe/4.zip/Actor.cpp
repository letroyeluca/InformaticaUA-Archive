//
// Created by mathijs on 12/8/24.
//

#include "Actor.h"

Actor::Actor(const string &firstname, const string &lastname) : firstname(firstname), lastname(lastname) {}
