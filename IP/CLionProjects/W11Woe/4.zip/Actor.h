//
// Created by mathijs on 12/8/24.
//

#ifndef W11WOE_ACTOR_H
#define W11WOE_ACTOR_H
#include <string>
using namespace std;
class Actor {
public:
    string firstname;
    string lastname;

    Actor(const string &firstname, const string &lastname);
};


#endif //W11WOE_ACTOR_H
