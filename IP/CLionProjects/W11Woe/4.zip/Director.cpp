//
// Created by mathijs on 12/8/24.
//

#include "Director.h"

Director::Director(const string &firstname, const string &lastname) : firstname(firstname), lastname(lastname) {}
