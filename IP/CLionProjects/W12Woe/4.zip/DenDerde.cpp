//
// Created by mathijs on 12/11/24.
//

#include "DenDerde.h"
#include <iostream>
DenDerde::DenDerde() {
    std::cout << "3, ";
}

DenDerde::~DenDerde() {
    std::cout << "5, ";
}
