//
// Created by mathijs on 12/11/24.
//

#ifndef W12WOE_DENDERDE_H
#define W12WOE_DENDERDE_H


class DenDerde {
public:
    DenDerde();

    virtual ~DenDerde();
};


#endif //W12WOE_DENDERDE_H
