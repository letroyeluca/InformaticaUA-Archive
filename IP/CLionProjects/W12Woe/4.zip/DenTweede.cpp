//
// Created by mathijs on 12/11/24.
//

#include "DenTweede.h"
#include <iostream>
using namespace std;
DenTweede::DenTweede() {
    cout << "1, ";
}

DenTweede::~DenTweede() {
    cout << "8.";
}
