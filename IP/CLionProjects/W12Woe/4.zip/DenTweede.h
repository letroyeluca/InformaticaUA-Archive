//
// Created by mathijs on 12/11/24.
//

#ifndef W12WOE_DENTWEEDE_H
#define W12WOE_DENTWEEDE_H


class DenTweede {
public:
    DenTweede();

    virtual ~DenTweede();
};


#endif //W12WOE_DENTWEEDE_H
