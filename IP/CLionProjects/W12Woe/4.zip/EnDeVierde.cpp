//
// Created by mathijs on 12/11/24.
//

#include "EnDeVierde.h"
#include <iostream>
EnDeVierde::EnDeVierde() {
    std::cout << "2, ";
}

EnDeVierde::~EnDeVierde() {
    std::cout << "7, ";
}
