//
// Created by mathijs on 12/11/24.
//

#ifndef W12WOE_ENDEVIERDE_H
#define W12WOE_ENDEVIERDE_H


class EnDeVierde {
public:
    EnDeVierde();

    virtual ~EnDeVierde();
};


#endif //W12WOE_ENDEVIERDE_H
