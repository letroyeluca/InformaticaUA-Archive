//
// Created by mathijs on 12/18/24.
//

#include "Level.h"

Level::~Level() = default;

Level::Level(const string &name) : name(name) {}
