//
// Created by mathijs on 12/18/24.
//

#ifndef W13WOE_LEVEL_H
#define W13WOE_LEVEL_H

#include <string>

using namespace std;
class Level {
private:
    string name;
public:
    virtual ~Level();

    explicit Level(const string &name);
};


#endif //W13WOE_LEVEL_H
