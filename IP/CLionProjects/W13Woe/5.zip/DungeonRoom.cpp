//
// Created by mathijs on 12/18/24.
//

#include "DungeonRoom.h"

DungeonRoom::DungeonRoom(const string &description) : Room(description) {}
