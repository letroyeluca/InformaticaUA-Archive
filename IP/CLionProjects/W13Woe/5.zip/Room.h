//
// Created by mathijs on 12/18/24.
//

#ifndef W13WOE_ROOM_H
#define W13WOE_ROOM_H
#include <string>

using namespace std;
class Room {
protected:
    string description;
public:
    explicit Room(const string &description);

    virtual ~Room();

    virtual string toString() const;
};


#endif //W13WOE_ROOM_H
