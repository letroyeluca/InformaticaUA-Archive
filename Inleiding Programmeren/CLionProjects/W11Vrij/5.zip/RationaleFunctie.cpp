#include "RationaleFunctie.h"
#include <iostream>
#include <sstream>
#include <regex>
#include "VeeltermFunctie.h"
using namespace std;
const string &RationaleFunctie::getNaam() const {
    return naam;
}

void RationaleFunctie::setNaam(const string &naam) {
    RationaleFunctie::naam = naam;
}

void RationaleFunctie::setTeller(const VeeltermFunctie &teller) {
    RationaleFunctie::teller = teller;
}

void RationaleFunctie::setNoemer(const VeeltermFunctie &noemer) {

    if (noemer.getCoefficienten()[0] == 0 && noemer.getCoefficienten().size() == 1){
        cout << "Ongeldige noemer" << endl;
        return;
    }
    RationaleFunctie::noemer = noemer;
}

string RationaleFunctie::toString() const {
    ostringstream out;
    regex pattern(R"(\w+\(x\) = )");
    string noemerstring = regex_replace(noemer.toString(), pattern, "");
    string tellerstring = regex_replace(teller.toString(), pattern, "");
    out << naam << "(x) = " << "(" << tellerstring << ") / (" << noemerstring << ")";
    return out.str();
}

double RationaleFunctie::berekenFunctiewaarde(double x) {
    double noemerWaarde = noemer.berekenFunctiewaarde(x);
    if (noemerWaarde == 0) {
        cout << "Deze waarde ligt buiten het domein van de functie" << endl;
        return 0;
    }
    double tellerWaarde = teller.berekenFunctiewaarde(x);
    return tellerWaarde / noemerWaarde;
}
