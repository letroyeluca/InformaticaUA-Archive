//
// Created by mathijs on 12/8/24.
//

#ifndef W11WOE_DIRECTOR_H
#define W11WOE_DIRECTOR_H
#include <string>
using namespace std;
class Director {
public:
    string firstname;
    string lastname;

    Director(const string &firstname, const string &lastname);
};


#endif //W11WOE_DIRECTOR_H
