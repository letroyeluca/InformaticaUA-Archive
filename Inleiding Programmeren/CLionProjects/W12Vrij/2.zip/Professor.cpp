//
// Created by mathijs on 12/18/24.
//

#include "Professor.h"

Professor::Professor(const string &voornaam, const string &achternaam) : achternaam(achternaam), voornaam(voornaam) {}

const string &Professor::getAchternaam() const {
    return achternaam;
}

const string &Professor::getVoornaam() const {
    return voornaam;
}

string Professor::toString() const {
    return "Professor " + getVoornaam() + " " + getAchternaam();
}

void Professor::geeft(Cursus * newCursus) {
    cursussen.push_back(newCursus);
}

