//
// Created by mathijs on 12/18/24.
//

#ifndef W12VRIJ_PROFESSOR_H
#define W12VRIJ_PROFESSOR_H

#include <string>
#include <vector>

using namespace std;
class Cursus;
class Professor {
private:
    string achternaam;
    string voornaam;
    vector<Cursus*> cursussen;
public:
    Professor(const string &achternaam, const string &voornaam);

    const string &getAchternaam() const;

    const string &getVoornaam() const;

    string toString() const;

    void geeft(Cursus*);

};


#endif //W12VRIJ_PROFESSOR_H
