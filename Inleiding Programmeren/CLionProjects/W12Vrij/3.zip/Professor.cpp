//
// Created by mathijs on 12/18/24.
//

#include "Professor.h"

Professor::Professor(const string &voornaam, const string &achternaam) : Persoon(voornaam,achternaam){}

string Professor::toString() const {
    return "Professor " + Persoon::toString();
}

void Professor::geeft(Cursus * newCursus) {
    cursussen.push_back(newCursus);
}

