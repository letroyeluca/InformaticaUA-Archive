//
// Created by mathijs on 12/18/24.
//

#ifndef W12VRIJ_PROFESSOR_H
#define W12VRIJ_PROFESSOR_H

#include <string>
#include <vector>
#include "Persoon.h"

using namespace std;
class Cursus;
class Professor : Persoon{
private:
    vector<Cursus*> cursussen;
public:
    Professor(const string &achternaam, const string &voornaam);

    string toString() const;

    void geeft(Cursus*);

};


#endif //W12VRIJ_PROFESSOR_H
