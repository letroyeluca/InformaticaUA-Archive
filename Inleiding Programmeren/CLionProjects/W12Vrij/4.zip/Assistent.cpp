//
// Created by mathijs on 12/18/24.
//

#include "Assistent.h"

Professor *Assistent::getBegeleider() const {
    return begeleider;
}

void Assistent::setBegeleider(Professor *begeleider) {
    Assistent::begeleider = begeleider;
}

Assistent::Assistent(const string &voornaam, const string &achternaam) : Lesgever(voornaam, achternaam) {}
