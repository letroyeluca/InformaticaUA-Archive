//
// Created by mathijs on 12/18/24.
//

#include "Professor.h"

Professor::Professor(const string &voornaam, const string &achternaam) : Lesgever(voornaam,achternaam){}

string Professor::toString() const {
    return "Professor " + Lesgever::toString();
}


void Professor::voegAssistentToe(Assistent * assistent) {
    assistenten.push_back(assistent);
}

