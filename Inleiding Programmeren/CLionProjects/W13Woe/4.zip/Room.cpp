//
// Created by mathijs on 12/18/24.
//

#include "Room.h"

Room::Room(const string &description) : description(description) {}

Room::~Room() {

}

string Room::toString() const {
    return "This is a room called '" + description + "'";
}
