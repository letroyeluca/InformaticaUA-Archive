//
// Created by mathijs on 12/18/24.
//

#ifndef W13WOE_DUNGEONROOM_H
#define W13WOE_DUNGEONROOM_H


#include "Room.h"

class DungeonRoom : public Room{
public:
    explicit DungeonRoom(const string &description);
};


#endif //W13WOE_DUNGEONROOM_H
